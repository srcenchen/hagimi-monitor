import Darwin
import Foundation
import IOKit
import OSLog

nonisolated final class GPUSampler: MonitorSampler, Sendable {
    var kind: MonitorKind { .gpu }

    func sample(previous: MonitorModule?) -> MonitorModule {
        guard let reading = gpuReading() else {
            AppLogger.sampler.error("gpuReading() returned nil, GPU data unavailable")
            return placeholderModule(.gpu, summary: String(localized: "sampler.unavailable"))
        }

        let utilization = min(100, max(0, reading.utilization))
        var metrics = [
            MonitorMetric(name: "usage", value: percent(utilization), numericValue: utilization),
        ]

        #if DIRECT_DISTRIBUTION
        // 频率档来自 IOReport 私有 API，仅 Direct 版可读，紧跟 GPU 占用之后。
        let clock = IOReportPowerSampler.shared.sample().gpuClock
        if let clock {
            let clockValue = clock.dominantState.flatMap { state in
                clock.dominantResidencyPercent.map { "\(state) \(percent($0))" }
            } ?? "--"
            metrics.append(MonitorMetric(
                name: "clock-state",
                value: clockValue,
                numericValue: clock.dominantResidencyPercent
            ))
        }
        #endif

        metrics.append(contentsOf: [
            MonitorMetric(name: "gpu-memory", value: reading.usedMemory.map(bytes) ?? "--", numericValue: reading.usedMemory),
            MonitorMetric(name: "allocated", value: reading.allocatedMemory.map(bytes) ?? "--")
        ])

        if let renderUtilization = reading.renderUtilization {
            metrics.append(MonitorMetric(name: "render", value: percent(renderUtilization), numericValue: renderUtilization))
        }

        if let tilerUtilization = reading.tilerUtilization {
            metrics.append(MonitorMetric(name: "tiler", value: percent(tilerUtilization), numericValue: tilerUtilization))
        }

        #if DIRECT_DISTRIBUTION
        // 限频与功耗上限虽然长期停在 0% / 100%，但它们是会变的实测值
        // （Apple 的 PPM 上限会随电源策略移动），隐藏会让「正常」与「功能不可用」
        // 无法区分。
        if let clock {
            metrics.append(MonitorMetric(
                name: "throttle",
                value: percent(clock.throttlePercent),
                numericValue: clock.throttlePercent
            ))
            if let cap = clock.powerCapPercent {
                metrics.append(MonitorMetric(name: "power-cap", value: percent(cap), numericValue: cap))
            }
        }
        #endif

        return MonitorModule(
            kind: .gpu,
            value: utilization,
            summary: percent(utilization),
            metrics: metrics,
            samples: seedSamples(utilization)
        )
    }

    private func gpuReading() -> GPUReading? {
        let accelerators = acceleratorServices()
        guard !accelerators.isEmpty else {
            AppLogger.sampler.error("No IOAccelerator services found")
            return nil
        }
        defer {
            accelerators.forEach { IOObjectRelease($0) }
        }

        var best: GPUReading?
        for accelerator in accelerators {
            guard let stats = registryDictionaryValue(accelerator, "PerformanceStatistics") else {
                AppLogger.sampler.error("Failed to read PerformanceStatistics from IOAccelerator service")
                continue
            }

            let utilization = doubleValue(stats["Device Utilization %"])
                ?? doubleValue(stats["GPU Activity(%)"])
                ?? 0
            let render = doubleValue(stats["Renderer Utilization %"])
            let tiler = doubleValue(stats["Tiler Utilization %"])
            let usedMemory = doubleValue(stats["In use system memory"])
            let allocatedMemory = doubleValue(stats["Alloc system memory"])
            let model = registryStringValue(accelerator, "model")
                ?? registryStringValue(accelerator, "IOClass")
                ?? "GPU"

            let reading = GPUReading(
                model: model,
                utilization: utilization,
                renderUtilization: render,
                tilerUtilization: tiler,
                usedMemory: usedMemory,
                allocatedMemory: allocatedMemory
            )

            if best == nil || reading.utilization > (best?.utilization ?? 0) {
                best = reading
            }
        }

        return best
    }

    private func acceleratorServices() -> [io_service_t] {
        var iterator: io_iterator_t = 0
        let result = IOServiceGetMatchingServices(kIOMainPortDefault, IOServiceMatching("IOAccelerator"), &iterator)
        guard result == KERN_SUCCESS else {
            AppLogger.sampler.error("IOServiceGetMatchingServices for IOAccelerator failed with result: \(result)")
            return []
        }
        defer { IOObjectRelease(iterator) }

        var services: [io_service_t] = []
        while true {
            let service = IOIteratorNext(iterator)
            guard service != IO_OBJECT_NULL else {
                break
            }
            services.append(service)
        }
        return services
    }
}

private struct GPUReading {
    let model: String
    let utilization: Double
    let renderUtilization: Double?
    let tilerUtilization: Double?
    let usedMemory: Double?
    let allocatedMemory: Double?
}
