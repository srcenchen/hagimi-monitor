import AppKit
import SwiftUI

/// 设置页统一滚动容器:内容不足一屏时撑满可视区(配合页内 `Spacer`
/// 实现"关于"页底部署名沉底),超过一屏时正常滚动,任意窗口高度下不裁切内容。
struct SettingsPage<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        GeometryReader { proxy in
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    content
                }
                .controlSize(.small)
                .padding(.top, 34)
                .padding(.horizontal, 36)
                .padding(.bottom, 28)
                .frame(maxWidth: .infinity, alignment: .topLeading)
                .frame(minHeight: proxy.size.height, alignment: .topLeading)
            }
        }
    }
}

struct SettingsGroup<Content: View, TitleAccessory: View>: View {
    var title: String?
    /// 标题行右侧挂件(如快捷操作按钮);无标题时不展示。
    var titleAccessory: TitleAccessory?
    let content: Content

    init(_ title: String? = nil,
         @ViewBuilder titleAccessory: () -> TitleAccessory,
         @ViewBuilder content: () -> Content) {
        self.title = title
        self.titleAccessory = titleAccessory()
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            if let title {
                SettingsGroupTitle(title) { titleAccessory }
            }

            SettingsCard {
                content
            }
        }
    }
}

extension SettingsGroup where TitleAccessory == EmptyView {
    /// 无标题挂件的便捷入口,保持旧调用写法不变。
    init(_ title: String? = nil, @ViewBuilder content: () -> Content) {
        self.init(title, titleAccessory: { EmptyView() }, content: content)
    }
}

/// 分组标题行:与分组卡片配套的排版。单独抽出是因为「工具」这类条目要
/// 标题 + 各自成卡的一排卡片,而不是标题 + 单张卡片。
struct SettingsGroupTitle<Accessory: View>: View {
    let title: String
    let accessory: Accessory

    init(_ title: String, @ViewBuilder accessory: () -> Accessory) {
        self.title = title
        self.accessory = accessory()
    }

    var body: some View {
        HStack(alignment: .center) {
            Text(title)
                .font(.headline.weight(.semibold))
                .padding(.horizontal, 2)
            Spacer(minLength: 0)
            accessory
        }
    }
}

extension SettingsGroupTitle where Accessory == EmptyView {
    init(_ title: String) {
        self.init(title, accessory: { EmptyView() })
    }
}

/// 单张设置卡片表面。分组内默认只有一张(SettingsGroup 包住),条目各自成卡
/// 时由调用方并排放多张。
struct SettingsCard<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        // 分组背景用平面浅色主题表面,不叠加玻璃:玻璃在切换外观/配色时整块重合成,
        // 是组内控件闪烁的诱因(面板行级也因同一诱因降级,见 CompatibleGlassEffect 注释)。
        VStack(spacing: 0) {
            content
        }
        .background(.quaternary.opacity(0.42), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
    }
}

/// 行/卡片行头按钮的通用样式:按压不做任何视觉变化(无变暗/无位移),
/// 状态反馈交给各自的内容过渡或 hover。
struct StaticPressButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
    }
}

struct SettingsRow<Accessory: View>: View {
    let title: String
    var subtitle: String?
    let accessory: Accessory

    init(title: String, subtitle: String? = nil, @ViewBuilder accessory: () -> Accessory) {
        self.title = title
        self.subtitle = subtitle
        self.accessory = accessory()
    }

    var body: some View {
        HStack(alignment: subtitle == nil ? .center : .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.body.weight(.medium))

                if let subtitle {
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer(minLength: 16)

            accessory
        }
        .padding(.horizontal, 14)
        .padding(.vertical, subtitle == nil ? 10 : 11)
        .frame(minHeight: subtitle == nil ? 44 : 58)
        .frame(maxWidth: .infinity)
    }
}

struct SettingsDivider: View {
    var body: some View {
        Rectangle()
            .fill(.separator.opacity(0.48))
            .frame(height: 1)
            .padding(.leading, 14)
    }
}

struct SettingsTip: View {
    let text: String

    init(_ text: String) {
        self.text = text
    }

    var body: some View {
        HStack(spacing: 4) {
            Spacer(minLength: 0)
            Image(systemName: "info.circle")
                .font(.caption2.weight(.medium))
            Text(text)
                .font(.caption2)
        }
        .foregroundStyle(.tertiary)
    }
}

struct SettingsIconHeader<Accessory: View>: View {
    let title: String
    let subtitle: String
    let footnote: String
    let imageName: String
    let accessory: Accessory

    init(
        title: String,
        subtitle: String,
        footnote: String = "",
        imageName: String,
        @ViewBuilder accessory: () -> Accessory = { EmptyView() }
    ) {
        self.title = title
        self.subtitle = subtitle
        self.footnote = footnote
        self.imageName = imageName
        self.accessory = accessory()
    }

    var body: some View {
        let header = HStack(spacing: 12) {
            Image(imageName)
                .resizable()
                .frame(width: 46, height: 46)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.headline.weight(.semibold))

                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                if !footnote.isEmpty {
                    Text(footnote)
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
            }

            Spacer(minLength: 0)

            accessory
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 14)

        // 与 SettingsGroup 同一平面主题表面。
        header
            .background(.quaternary.opacity(0.42), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}
