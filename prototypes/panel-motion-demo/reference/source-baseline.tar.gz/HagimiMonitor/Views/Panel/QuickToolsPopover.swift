import AppKit
import Combine
import CoreGraphics
import SwiftUI

/// 快捷功能条目。键盘锁定双渠道均为事件 tap 拦截
/// (见 KeyboardLockController),解锁入口即本磁贴开关。
enum QuickToolKind: CaseIterable {
    case keyboardLock
    case systemAwake
    case displayAwake

    /// 设置持久化用的稳定标识:与展示名/图标解耦,改名不影响已存设置;
    /// 新增工具需补 case 与 titleKey/symbol/storageKey,并在
    /// MonitorSettings 的 introducedByVersion 迁移登记一次。
    var storageKey: String {
        switch self {
        case .keyboardLock: "keyboardLock"
        case .systemAwake: "systemAwake"
        case .displayAwake: "displayAwake"
        }
    }

    var titleKey: String.LocalizationValue {
        switch self {
        case .keyboardLock: "quicktools.keyboard-lock"
        case .systemAwake: "quicktools.system-awake"
        case .displayAwake: "quicktools.display-awake"
        }
    }

    var symbol: String {
        switch self {
        case .keyboardLock: "keyboard"
        case .systemAwake: "laptopcomputer"
        case .displayAwake: "sun.max"
        }
    }

    /// 该工具是否带可调参数(决定设置页卡片给不给折叠箭头)。没有参数还折叠
    /// 就是点开一个空面板,不如老实做单行开关。
    var hasParameters: Bool {
        switch self {
        case .keyboardLock: true
        case .systemAwake, .displayAwake: false
        }
    }
}

/// 每个入口按钮实例独享的锚点盒:面板每秒重渲染会重建视图树,@State
/// 持有的盒子跨渲染存活,宿主 NSView 换新时同步弱引用。菜单栏面板与
/// 钉住面板各持一个实例,浮层始终锚定到实际被点击的那块面板。
@MainActor
final class QuickToolsAnchorBox {
    fileprivate weak var view: NSView?
}

/// 把 SwiftUI 按钮的宿主 NSView 写入锚点盒,供 NSPopover 定位。
struct QuickToolsAnchorView: NSViewRepresentable {
    let box: QuickToolsAnchorBox

    func makeNSView(context: Context) -> NSView {
        let view = NSView()
        box.view = view
        return view
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        box.view = nsView
    }
}

/// 工具浮层呈现器:NSPopover 挂在面板窗口下,独立于面板每秒刷新
/// (macOS 26+ 自动液态玻璃外观)。transient 行为:点击浮层外自动收起。
@MainActor
final class QuickToolsPopoverPresenter: NSObject, NSPopoverDelegate {
    private let popover = NSPopover()
    /// 浮层关闭回调:同步 store 的呈现状态(面板入口按钮的打开态高亮)。
    private let onClosed: @MainActor () -> Void
    /// 内容控制器:首次构建完成布局并测定 contentSize,之后重开仅更新
    /// 主题,消除弹出前的布局延迟。关闭后释放:内容结构变化(如磁贴增删)
    /// 时下次打开重新测定尺寸,避免沿用过期 contentSize。
    private var hostingController: NSHostingController<QuickToolsPopoverView>?
    /// 最近一次关闭时刻:transient 浮层点外部会自动收起,同一次点击的
    /// mouseDown 关浮层、mouseUp 到达入口按钮,需识别为「关闭」而非
    /// 重新弹出。窗口期低于人手两次独立点击的最小间隔,快速连点不被吞。
    private var lastCloseMediaTime: CFTimeInterval = 0
    /// 当前浮层锚定的入口盒(弱引用避免与 store/视图形成强环)。header
    /// 徽章与底部工具按钮各持不同盒,据此区分来源,实现「全部工具关闭
    /// 时仅收起 header 锚定的浮层」。
    private weak var activeAnchor: QuickToolsAnchorBox?

    init(onClosed: @escaping @MainActor () -> Void) {
        self.onClosed = onClosed
        super.init()
        popover.behavior = .transient
        // 关闭动画禁用:浮层是面板的子窗口,点行展开时 mouseDown 触发的
        // 浮层渐隐(约 0.15s)会与 mouseUp 的窗口高度补间重叠,子窗口逐帧
        // 跟随父窗口重定位,引发布局抖动(面板内容瞬移后回弹)。
        // 即时脱离让两种动画永不重叠。
        popover.animates = false
        popover.delegate = self
    }

    /// 以入口按钮的锚点盒向下弹出/收起浮层。settings 提供工具显隐过滤
    /// (用户在设置「小工具」页关闭的工具不渲染磁贴)。
    func toggle(theme: MonitorPanelTheme, settings: MonitorSettings, anchor: QuickToolsAnchorBox) {
        if popover.isShown {
            popover.performClose(nil)
            return
        }
        guard CACurrentMediaTime() - lastCloseMediaTime > 0.15 else { return }
        guard let anchorView = anchor.view, anchorView.window != nil else { return }
        let controller = prepareHostingController(theme: theme, settings: settings)
        popover.contentViewController = controller
        activeAnchor = anchor
        QuickToolsStore.shared.isPopoverPresented = true
        popover.show(relativeTo: anchorView.bounds, of: anchorView, preferredEdge: .minY)
    }

    func dismiss() {
        guard popover.isShown else { return }
        popover.performClose(nil)
    }

    /// 浮层当前是否锚定在指定盒上(区分 header 徽章与底部工具入口)。
    func isShown(from box: QuickToolsAnchorBox) -> Bool {
        popover.isShown && activeAnchor === box
    }

    /// 内容布局高度变化(权限提示行出现/消失)时同步浮层尺寸。NSPopover
    /// 不会自动跟随内容生长,不重算会在提示行出现时裁切、消失时留白。
    func refreshContentSize() {
        guard popover.isShown, let controller = hostingController else { return }
        controller.view.layoutSubtreeIfNeeded()
        let fitting = controller.view.fittingSize
        if fitting.width > 1, fitting.height > 1 { popover.contentSize = fitting }
    }

    nonisolated func popoverDidClose(_ notification: Notification) {
        MainActor.assumeIsolated {
            lastCloseMediaTime = CACurrentMediaTime()
            hostingController = nil
            activeAnchor = nil
            onClosed()
        }
    }

    /// 预热内容控制器:未布局时 fittingSize 读数为零,浮层会以零尺寸弹出
    /// 导致「点了没反应」;布局异常时退回定宽估算尺寸兜底。
    private func prepareHostingController(theme: MonitorPanelTheme, settings: MonitorSettings) -> NSHostingController<QuickToolsPopoverView> {
        if let existing = hostingController {
            existing.rootView = QuickToolsPopoverView(settings: settings, theme: theme)
            return existing
        }
        let controller = NSHostingController(rootView: QuickToolsPopoverView(settings: settings, theme: theme))
        controller.view.layoutSubtreeIfNeeded()
        let fitting = controller.view.fittingSize
        popover.contentSize = fitting.width > 1 && fitting.height > 1
            ? fitting
            : CGSize(width: 290, height: 220)
        hostingController = controller
        return controller
    }
}

/// 工具浮层内容:控制中心风格的点亮式磁贴,激活态整体点亮,
/// 与只读监控数据在视觉上严格区分。不设标题行——浮层由「工具」
/// 按钮弹出,内容即入口本身,标题行只占纵向空间。
struct QuickToolsPopoverView: View {
    @ObservedObject private var store = QuickToolsStore.shared
    @ObservedObject var settings: MonitorSettings
    let theme: MonitorPanelTheme

    /// 浮层展开时已在呈现的工具集合:只要浮层没关,中途关闭功能绝不能把卡片
    /// 当场从用户眼前抹去,避免操作中途卡片骤然消失的恶劣体验。
    @State private var retainedKinds: Set<QuickToolKind> = []

    /// 按设置页「小工具」的显隐开关过滤磁贴;激活中的工具豁免(见
    /// QuickToolsStore.isActive),保证运行中的工具永远有操作入口。
    /// 新增工具补 QuickToolKind case 即自动出现。
    private var visibleKinds: [QuickToolKind] {
        QuickToolKind.allCases.filter { kind in
            settings.isQuickToolVisible(kind) || store.isActive(kind) || retainedKinds.contains(kind)
        }
    }

    var body: some View {
        VStack(spacing: 7) {
            ForEach(visibleKinds, id: \.self) { kind in
                QuickToolTile(kind: kind, theme: theme)
            }
        }
        .padding(12)
        // 浮层宽度按最长英文标题「Prevent Idle Sleep」预算:标题可用
        // 空间 = 宽 − 内外边距 − 徽章 32 − 间距 − 开关,290pt 时留有余量。
        .frame(width: 290)
        .onAppear {
            store.refreshKeyboardLockPermission()
            retainedKinds = Set(QuickToolKind.allCases.filter {
                settings.isQuickToolVisible($0) || store.isActive($0)
            })
        }
        // 浮层开着期间每 2s 校准一次键盘锁定授权状态(App Store 渠道撤销
        // 无事件通知,只能轮询);浮层关闭时 hostingController 释放,本视图
        // 随之下树,计时器随之停止,无空转。
        .onReceive(
            Timer.publish(every: 2, on: .main, in: .common).autoconnect()
        ) { _ in
            store.refreshKeyboardLockPermission()
        }
        // 提示行出现/消失改变磁贴高度,同步浮层尺寸避免裁切或留白。
        .onChange(of: store.keyboardLockHint) { _, _ in
            store.popoverPresenter.refreshContentSize()
        }
    }
}

/// 单个功能磁贴:圆形徽章 + 名称 + 系统标准开关。点亮时底色、
/// 描边、徽章沿同一条弹簧曲线整体过渡。
private struct QuickToolTile: View {
    @ObservedObject private var store = QuickToolsStore.shared
    let kind: QuickToolKind
    let theme: MonitorPanelTheme

    /// 点亮/熄灭共用的弹簧曲线:磁贴各元素同节奏,避免"生硬瞬切"。
    private static let toggleSpring = Animation.spring(response: 0.32, dampingFraction: 0.8)

    private var isOn: Bool {
        switch kind {
        case .keyboardLock: store.keyboardLocked
        case .systemAwake: store.systemSleepPrevented
        case .displayAwake: store.displayAwake
        }
    }

    /// 键盘锁定的提示行:只在"此刻会出问题"时出现——权限未授予,或
    /// 「仅内置」锁定中却没有外接键盘(此时内置键盘被拦截且无处可输入)。
    /// 范围本身不在此展示:它是设一次用很久的偏好,放在设置页。
    private var hint: String? {
        kind == .keyboardLock ? store.keyboardLockHint : nil
    }

    private var accent: Color {
        theme.palette.quickToolTint
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 10) {
                ZStack {
                    Circle()
                        .fill(isOn ? accent : theme.palette.trackFill)
                    Image(systemName: kind.symbol)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(isOn ? Color.white : theme.secondaryText)
                }
                .frame(width: 32, height: 32)

                Text(String(localized: kind.titleKey))
                    .font(.system(size: 12.5, weight: .semibold))
                    .foregroundStyle(theme.primaryText)
                    .lineLimit(1)

                Spacer(minLength: 6)

                // 系统标准开关:macOS 26+ 自动液态玻璃,tint 染强调色保留点亮质感。
                // 绑定直接联动 toggle,支持原生的点击与拖动交互。
                Toggle(String(localized: kind.titleKey), isOn: Binding(
                    get: { isOn },
                    set: { _ in toggle() }
                ))
                .labelsHidden()
                .toggleStyle(.switch)
                .tint(accent)
            }

            if let hint {
                Text(hint)
                    .font(.system(size: 10.5))
                    // 与标题同色而非强调色:小字承载体量与标题一致,深色模式下
                    // 橙色低对比难读;灰色白承袭 primaryText,两行一体。
                    .foregroundStyle(theme.primaryText)
                    .lineLimit(2)
                    // 与标题文字左对齐:磁贴水平 padding 10 + 徽章 32 + 间距 10。
                    .padding(.leading, 42)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: MonitorConstants.rowCornerRadius, style: .continuous)
                .fill(isOn ? theme.palette.quickToolActiveFill : theme.palette.trackFill)
        )
        .overlay(
            RoundedRectangle(cornerRadius: MonitorConstants.rowCornerRadius, style: .continuous)
                .strokeBorder(isOn ? accent.opacity(0.5) : Color.white.opacity(0.08), lineWidth: 0.5)
        )
        .contentShape(RoundedRectangle(cornerRadius: MonitorConstants.rowCornerRadius, style: .continuous))
        .onTapGesture {
            toggle()
        }
        .animation(Self.toggleSpring, value: isOn)
        .animation(Self.toggleSpring, value: hint)
    }

    /// 状态切换统一包在同一条弹簧动画里:store 的 @Published 变化经
    /// withAnimation 传递到所有观察视图,与磁贴自身的 animation 双保险。
    private func toggle() {
        withAnimation(Self.toggleSpring) {
            switch kind {
            case .keyboardLock: store.toggleKeyboardLock()
            case .systemAwake: store.toggleSystemSleepPrevention()
            case .displayAwake: store.toggleDisplayAwake()
            }
        }
    }
}

/// 面板底部的工具入口按钮。独立子视图观察 QuickToolsStore:
/// 开关状态与浮层开闭只重绘本按钮,不牵动整块面板,避免面板闪烁。
struct QuickToolsEntryButton: View {
    @ObservedObject private var store = QuickToolsStore.shared
    @ObservedObject var settings: MonitorSettings
    let theme: MonitorPanelTheme
    var minimumHeight: CGFloat? = nil
    @State private var anchor = QuickToolsAnchorBox()

    var body: some View {
        Button {
            store.popoverPresenter.toggle(theme: theme, settings: settings, anchor: anchor)
        } label: {
            Label(String(localized: "panel.tools"), systemImage: "wrench.and.screwdriver")
                .lineLimit(1)
                .frame(maxWidth: .infinity)
        }
        .compatibleButtonStyle(minimumHeight: minimumHeight)
        .background(QuickToolsAnchorView(box: anchor))
        .overlay(
            RoundedRectangle(cornerRadius: MonitorConstants.rowCornerRadius, style: .continuous)
                .strokeBorder(Color.white.opacity(0.22), lineWidth: 0.5)
                .opacity(store.isPopoverPresented ? 1 : 0)
                .allowsHitTesting(false)
                .animation(.easeInOut(duration: 0.18), value: store.isPopoverPresented)
        )
        .overlay(alignment: .topTrailing) {
            Circle()
                .fill(theme.palette.quickToolTint)
                .frame(width: 5, height: 5)
                .padding(.trailing, 12)
                .opacity(store.anyActive ? 1 : 0)
                .animation(.easeInOut(duration: 0.18), value: store.anyActive)
        }
    }
}
