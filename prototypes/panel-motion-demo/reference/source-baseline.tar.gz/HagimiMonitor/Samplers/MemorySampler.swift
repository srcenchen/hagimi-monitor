import Darwin
import Foundation
import OSLog

/// 采样器由 SystemMonitorSampler 持有并在串行采样循环中调用，内部状态单线程顺序更新。
nonisolated final class MemorySampler: MonitorSampler, @unchecked Sendable {
    var kind: MonitorKind { .memory }

    // mach_host_self() 每次调用都会泄漏一个 host port 的 send right，累积到阈值会被
    // jetsam 静默 SIGKILL。缓存为 stored property，进程生命周期内只获取一次。
    private let host: mach_port_t
    private let totalMemorySize: Double

    init() {
        let hostPort = mach_host_self()
        self.host = hostPort
        self.totalMemorySize = Self.memoryTotalSize(host: hostPort)
    }

    func sample(previous: MonitorModule?) -> MonitorModule {
        var stats = vm_statistics64()
        var count = mach_msg_type_number_t(MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &stats) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                host_statistics64(host, HOST_VM_INFO64, $0, &count)
            }
        }

        guard result == KERN_SUCCESS else {
            AppLogger.sampler.error("host_statistics64 failed with result: \(result)")
            return placeholderModule(.memory, summary: String(localized: "sampler.unavailable"))
        }

        let pageSize = Double(getpagesize())
        let active = Double(stats.active_count) * pageSize
        let speculative = Double(stats.speculative_count) * pageSize
        let inactive = Double(stats.inactive_count) * pageSize
        let wired = Double(stats.wire_count) * pageSize
        let compressed = Double(stats.compressor_page_count) * pageSize
        let purgeable = Double(stats.purgeable_count) * pageSize
        let external = Double(stats.external_page_count) * pageSize
        let used = max(0, active + inactive + speculative + wired + compressed - purgeable - external)
        let total = totalMemorySize
        let percentage = total > 0 ? (used / total) * 100 : 0
        let swap = swapUsage()
        let pressure = memoryPressure()
        let pressurePercent = memoryPressurePercent()

        // 提取 swapins/swapouts（累计页面计数）
        let swapins = Int64(stats.swapins)
        let swapouts = Int64(stats.swapouts)

        var metrics = [
            MonitorMetric(name: "used", value: memoryBytes(used), numericValue: used),
            // 压力行自身携带离散等级,展开区过滤掉内部 pressure-level 后仍能正确着色。
            MonitorMetric(
                name: "pressure",
                value: pressure.level.identifier,
                numericValue: Double(pressure.level.rawValue)
            ),
            MonitorMetric(name: "swap-used", value: swapUsedText(swap), numericValue: swap?.used),
            MonitorMetric(name: "total", value: memoryBytes(total)),
            // 压缩内存(compressor_page_count):内存紧张时系统压缩页的占用,
            // 与活动监视器「被压缩」同口径。
            MonitorMetric(name: "compressed", value: memoryBytes(compressed), numericValue: compressed),
            MonitorMetric(name: "pressure-level", value: pressure.level.identifier, numericValue: Double(pressure.level.rawValue)),
            MonitorMetric(name: "swapins", value: String(swapins), numericValue: Double(swapins)),
            MonitorMetric(name: "swapouts", value: String(swapouts), numericValue: Double(swapouts))
        ]

        #if DIRECT_DISTRIBUTION
        let bwBytes = IOReportPowerSampler.shared.sample().memoryBandwidthBytesPerSec
        let gbPerSec = bwBytes.map { $0 / 1e9 }
        let bwText = gbPerSec.map { String(format: "%.1f GB/s", $0) } ?? "--"
        metrics.append(MonitorMetric(name: "memory-bandwidth", value: bwText, numericValue: gbPerSec, unit: " GB/s"))
        #endif

        return MonitorModule(
            kind: .memory,
            value: percentage,
            summary: percent(percentage),
            metrics: metrics,
            samples: seedSamples(percentage),
            pressure: pressure.level,
            pressureValue: pressurePercent,
            pressureSamples: pressurePercent.map(seedSamples) ?? []
        )
    }

    private static func memoryTotalSize(host: mach_port_t) -> Double {
        var info = host_basic_info()
        var count = mach_msg_type_number_t(MemoryLayout<host_basic_info_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                host_info(host, HOST_BASIC_INFO, $0, &count)
            }
        }
        guard result == KERN_SUCCESS else {
            return Double(ProcessInfo.processInfo.physicalMemory)
        }
        return Double(info.max_mem)
    }

    private func memoryPressure() -> MemoryPressureState {
        let vmPressureWarning: Int32 = 2
        let vmPressureCritical: Int32 = 4
        var pressureLevel = Int32(0)
        var size = MemoryLayout<Int32>.size
        let result = sysctlbyname("kern.memorystatus_vm_pressure_level", &pressureLevel, &size, nil, 0)
        guard result == 0 else {
            return .unknown
        }

        switch pressureLevel {
        case vmPressureWarning:
            return .warning
        case vmPressureCritical:
            return .critical
        default:
            return .normal
        }
    }

    /// 连续内存压力百分比。kern.memorystatus_level 是系统内存健康水位(0-100),
    /// 100 - 水位即活动监视器「内存压力」图的口径；离散压力等级几乎恒为正常,
    /// 画曲线没有信息量,故曲线用连续值。
    private func memoryPressurePercent() -> Double? {
        var level = Int32(0)
        var size = MemoryLayout<Int32>.size
        let result = sysctlbyname("kern.memorystatus_level", &level, &size, nil, 0)
        guard result == 0 else {
            return nil
        }
        return min(100, max(0, 100 - Double(level)))
    }

    private func swapUsage() -> SwapUsage? {
        var usage = xsw_usage()
        var size = MemoryLayout<xsw_usage>.stride
        let result = sysctlbyname("vm.swapusage", &usage, &size, nil, 0)
        guard result == 0 else {
            return nil
        }
        return SwapUsage(
            used: Double(usage.xsu_used),
            total: Double(usage.xsu_total),
            available: Double(usage.xsu_avail)
        )
    }

    private func swapUsedText(_ swap: SwapUsage?) -> String {
        guard let used = swap?.used, used > 0 else {
            return "--"
        }
        return memoryBytes(used)
    }
}

nonisolated private enum MemoryPressureState: Sendable {
    case normal
    case warning
    case critical
    case unknown

    var level: MemoryPressureLevel {
        switch self {
        case .normal: .normal
        case .warning: .warning
        case .critical: .critical
        case .unknown: .unknown
        }
    }
}

nonisolated private struct SwapUsage: Sendable {
    let used: Double
    let total: Double
    let available: Double
}
