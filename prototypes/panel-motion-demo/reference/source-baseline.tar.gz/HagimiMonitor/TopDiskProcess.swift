import AppKit
import Darwin
import Foundation

/// TopDiskProcess 仅持有不可变的只读属性；所持有的 NSImage 为 ProcessIconCache 生成的固定位图，
/// 跨线程传递用于视图绑定，不进行并发修改。
struct TopDiskProcess: Identifiable, Equatable, @unchecked Sendable {
    let pid: pid_t
    let name: String
    /// 自上次采样以来读取的字节增量。统计入库按窗口字节量累计,依赖该字段。
    let bytesRead: UInt64
    /// 自上次采样以来写入的字节增量。
    let bytesWritten: UInt64
    /// 按窗口时长归一的读速率(字节/秒),面板展示用——与网络 TOP 口径一致,
    /// 量纲不随采样窗口长短变化。
    let readRate: Double
    /// 按窗口时长归一的写速率(字节/秒)。
    let writeRate: Double
    let icon: NSImage?

    var id: pid_t { pid }

    static func == (lhs: TopDiskProcess, rhs: TopDiskProcess) -> Bool {
        lhs.pid == rhs.pid && lhs.name == rhs.name
            && lhs.readRate == rhs.readRate && lhs.writeRate == rhs.writeRate
    }
}

struct RawDiskProcess: Sendable {
    let pid: pid_t
    let path: String
    let fallbackName: String
    let bytesRead: UInt64
    let bytesWritten: UInt64
    /// 产出该组增量的差分窗口时长(秒),供速率归一。
    let windowSeconds: Double
}

/// 磁盘 I/O 差分游标:持有独立的进程累计基线,增量 = 本次累计 − 基线。
/// 面板(2s)与统计(60s)各持一个实例——基线共享时统计窗口会被面板采样
/// 截断成残量,×60s 外推入库即为失真数据。
/// 游标同时记录快照时刻,把差分窗口时长随结果下发,供展示侧归一成速率。
/// 安全不变式：内部状态仅在串行队列（procSampleQueue）上读写，不存在跨线程并发修改。
nonisolated final class DiskSnapshotCursor: @unchecked Sendable {
    private var previous: [pid_t: (read: UInt64, write: UInt64)] = [:]
    private var previousTime: Date?

    /// 后台采样磁盘 I/O 最高的 N 个进程。
    /// 使用 `proc_pid_rusage` 读取 `ri_diskio_bytesread` / `ri_diskio_byteswritten`,
    /// 维护快照计算增量，按宿主 App 合并子进程。
    func sampleTopDiskProcesses(limit: Int = 5, includeSystemProcesses: Bool = false) -> [RawDiskProcess] {
        let estimatedCount = proc_listallpids(nil, 0)
        guard estimatedCount > 0 else { return [] }

        let capacity = Int(estimatedCount) * 2
        var pids = [pid_t](repeating: 0, count: capacity)
        let bufferSizeInBytes = Int32(capacity * MemoryLayout<pid_t>.size)
        let pidCount = Int(proc_listallpids(&pids, bufferSizeInBytes))
        guard pidCount > 0 else { return [] }

        let now = Date()
        // 窗口下限 0.1s,与模块采样层(StorageSampler/NetworkSampler)同口径,
        // 防两次采样间隔过近时除法放大噪声。
        let window = previousTime.map { max(0.1, now.timeIntervalSince($0)) } ?? 0

        // responsiblePid -> (path, readDelta, writeDelta)
        var groups: [pid_t: (path: String, readDelta: UInt64, writeDelta: UInt64)] = [:]
        groups.reserveCapacity(pidCount)

        var currentSnapshot: [pid_t: (read: UInt64, write: UInt64)] = [:]
        currentSnapshot.reserveCapacity(pidCount)

        for i in 0..<min(pidCount, capacity) {
            let pid = pids[i]
            guard pid > 0 else { continue }

            var rusage = rusage_info_current()
            let result = withUnsafeMutablePointer(to: &rusage) { structPtr -> Int32 in
                structPtr.withMemoryRebound(to: rusage_info_t?.self, capacity: 1) { rawPtr in
                    proc_pid_rusage(pid, RUSAGE_INFO_CURRENT, rawPtr)
                }
            }
            guard result == 0 else { continue }

            let totalRead = rusage.ri_diskio_bytesread
            let totalWrite = rusage.ri_diskio_byteswritten
            currentSnapshot[pid] = (read: totalRead, write: totalWrite)

            // 计算增量
            let prev = previous[pid]
            let readDelta = prev.map { totalRead >= $0.read ? totalRead - $0.read : 0 } ?? 0
            let writeDelta = prev.map { totalWrite >= $0.write ? totalWrite - $0.write : 0 } ?? 0

            guard readDelta > 0 || writeDelta > 0 else { continue }

            let responsiblePid = responsiblePidResolver(pid)
            let groupKey: pid_t = responsiblePid > 0 ? responsiblePid : pid

            if groups[groupKey] == nil {
                groups[groupKey] = (path: executablePath(for: groupKey), readDelta: 0, writeDelta: 0)
            }
            groups[groupKey]?.readDelta += readDelta
            groups[groupKey]?.writeDelta += writeDelta
        }

        previous = currentSnapshot
        previousTime = now

        // 过滤系统进程，生成结果
        var result: [RawDiskProcess] = []
        result.reserveCapacity(groups.count)

        for (groupKey, group) in groups {
            let hostPath = group.path

            if isSystemProcessPath(hostPath, includeSystemProcesses: includeSystemProcesses) {
                continue
            }

            let fallbackName = hostPath.isEmpty ? "pid \(groupKey)" : (hostPath as NSString).lastPathComponent
            guard !fallbackName.isEmpty else { continue }

            result.append(RawDiskProcess(
                pid: groupKey,
                path: hostPath,
                fallbackName: fallbackName,
                bytesRead: group.readDelta,
                bytesWritten: group.writeDelta,
                windowSeconds: window
            ))
        }

        return Array(result.sorted {
            max($0.bytesRead, $0.bytesWritten) > max($1.bytesRead, $1.bytesWritten)
        }.prefix(limit))
    }
}

/// 用 NSRunningApplication(pid:) 为磁盘 I/O 采样结果补齐本地化名与 App 图标。
/// 可在任意线程调用,不依赖 NSWorkspace.shared.runningApplications 遍历。
nonisolated func enrichDisk(_ rawProcesses: [RawDiskProcess]) -> [TopDiskProcess] {
    return rawProcesses.map { raw in
        let app = NSRunningApplication(processIdentifier: pid_t(raw.pid))

        let name: String
        if let localized = app?.localizedName, !localized.isEmpty {
            name = localized
        } else {
            name = raw.fallbackName
        }

        let icon = ProcessIconCache.icon(forPID: pid_t(raw.pid), path: raw.path)

        return TopDiskProcess(
            pid: raw.pid, name: name,
            bytesRead: raw.bytesRead, bytesWritten: raw.bytesWritten,
            readRate: raw.windowSeconds > 0 ? Double(raw.bytesRead) / raw.windowSeconds : 0,
            writeRate: raw.windowSeconds > 0 ? Double(raw.bytesWritten) / raw.windowSeconds : 0,
            icon: icon
        )
    }
}
