import Foundation
import Testing
@testable import HagimiMonitorDirect

struct KeyboardLockControllerTests {
    @Test func keyboardLockScopeProperties() {
        #expect(KeyboardLockScope.allCases.count == 2)
        #expect(KeyboardLockScope.internalOnly.rawValue == "internalOnly")
        #expect(KeyboardLockScope.all.rawValue == "all")
    }

    /// 自动解锁档位是「防锁了就忘」的兜底,必须有一档默认值;0 表示"永不"
    /// (不启动兜底计时,锁定持续到用户手动关闭)。
    @Test func autoUnlockMinuteOptionsAreBounded() {
        #expect(KeyboardLockController.autoUnlockMinuteOptions == [10, 20, 30, 60, 0])
        #expect(KeyboardLockController.defaultAutoUnlockMinutes == 20)
        #expect(KeyboardLockController.autoUnlockMinuteOptions.contains(KeyboardLockController.defaultAutoUnlockMinutes))
    }

    /// 自动解锁时长是唯一持久化的键盘锁定设置:设置页写入、QuickToolsStore
    /// 启动时按同一常量恢复。字面量是落盘格式,不能随重构漂移。
    @Test func settingsAutoUnlockMinutesPersistence() {
        let suite = "settingsAutoUnlockMinutesPersistence"
        let defaults = UserDefaults(suiteName: suite)!
        defaults.removePersistentDomain(forName: suite)

        let settings = MonitorSettings(defaults: defaults)
        #expect(settings.keyboardLockAutoUnlockMinutes == 20)

        settings.keyboardLockAutoUnlockMinutes = 30
        #expect(defaults.integer(forKey: QuickToolsStore.autoUnlockMinutesDefaultsKey) == 30)

        let reloaded = MonitorSettings(defaults: defaults)
        #expect(reloaded.keyboardLockAutoUnlockMinutes == 30)
    }

    /// 非法存量值(如手改 defaults 成 999)回落默认档,不把兜底时长放大。
    @Test func settingsAutoUnlockMinutesFallsBackOnUnknownValue() {
        let suite = "settingsAutoUnlockMinutesFallsBack"
        let defaults = UserDefaults(suiteName: suite)!
        defaults.removePersistentDomain(forName: suite)
        defaults.set(999, forKey: QuickToolsStore.autoUnlockMinutesDefaultsKey)

        let settings = MonitorSettings(defaults: defaults)
        #expect(settings.keyboardLockAutoUnlockMinutes == KeyboardLockController.defaultAutoUnlockMinutes)
    }

    /// 外接键盘拦截范围偏好持久化:默认 false(仅拦截内置键盘),
    /// 设置页开启后落盘,重启与重载后按同一键恢复。
    @Test func settingsBlocksExternalPersistence() {
        let suite = "settingsBlocksExternalPersistence"
        let defaults = UserDefaults(suiteName: suite)!
        defaults.removePersistentDomain(forName: suite)

        let settings = MonitorSettings(defaults: defaults)
        #expect(settings.keyboardLockBlocksExternal == false)

        settings.keyboardLockBlocksExternal = true
        #expect(defaults.bool(forKey: QuickToolsStore.blocksExternalDefaultsKey) == true)

        let reloaded = MonitorSettings(defaults: defaults)
        #expect(reloaded.keyboardLockBlocksExternal == true)
    }

    @Test func scanExternalKeyboardsDoesNotCrash() {
        let keyboards = KeyboardLockController.scanExternalKeyboards()
        #expect(keyboards.count >= 0)
    }

    @Test func scanExternalKeyboardsExcludesMice() {
        let keyboards = KeyboardLockController.scanExternalKeyboards()
        for kbd in keyboards {
            #expect(!kbd.lowercased().contains("vxe"))
            #expect(!kbd.lowercased().contains("mouse"))
        }
    }

    /// 兜底时长在落锁时按用户档位确定;未指定时用默认档。
    @Test func controllerAutoUnlockIntervalFollowsRequestedMinutes() {
        let controller = KeyboardLockController()
        #expect(controller.autoUnlockInterval == TimeInterval(KeyboardLockController.defaultAutoUnlockMinutes * 60))
    }

    // MARK: - 「仅内置」事件归因

    /// 测试用归因器:1ms = 1 tick,时间窗断言直接用毫秒数表达。
    private func makeAttribution() -> KeyboardEventAttribution {
        KeyboardEventAttribution(ticksPerMillisecond: 1)
    }

    /// 主 bug 回归:内置键(空格)保持按住期间,HID 侧持续产生外接键活动,
    /// 内置键的自动重复不得因"外接侧有活动/有键按着"被放行。修复前按
    /// 「哪侧有键按下」兜底,该场景会把内置长按的重复混进外接打字流。
    @Test func autorepeatFollowsRecordedVerdictNotDownSets() {
        let a = makeAttribution()
        let space: Int64 = 49

        // 内置空格落下(时间窗归因为内置并记账)。
        a.recordHIDReport(usage: 0x2C, isDown: true, side: .builtIn, now: 1_000)
        #expect(a.decide(kind: .keyDown, keyCode: space, now: 1_100) == .builtIn)

        // 期间外接侧打字(别的键落下),内置空格自动重复到来。
        a.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_300)
        #expect(a.decide(kind: .keyDown, keyCode: 4, now: 1_350) == .external)

        // 空格的重复:记账是内置,即使外接侧有活动仍在窗内,也必须拦截。
        #expect(a.decide(kind: .keyDown, keyCode: space, isAutorepeat: true, now: 1_400) == .builtIn)
    }

    /// 自动重复跟随记账的正面场景:外接长按的重复放行,哪怕抬起前时间窗
    /// 已陈旧(长按不产生新 HID 报告)。
    @Test func externalAutorepeatSurvivesStaleWindows() {
        let a = makeAttribution()
        let key: Int64 = 4

        a.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_000)
        #expect(a.decide(kind: .keyDown, keyCode: key, now: 1_050) == .external)

        // 500ms 后无任何 HID 活动(长按中),重复应跟随记账放行。
        #expect(a.decide(kind: .keyDown, keyCode: key, isAutorepeat: true, now: 1_600) == .external)

        // 抬起同理,随后销账:再来的同键重复失去记账,默认拦截。
        #expect(a.decide(kind: .keyUp, keyCode: key, now: 1_700) == .external)
        #expect(a.decide(kind: .keyDown, keyCode: key, isAutorepeat: true, now: 1_750) == .builtIn)
    }

    /// 记账缺失(锁定中途开始/热切换 reset)时,自动重复退回时间窗:
    /// 陈旧证据下判内置拦截,不因另一侧有键按着而放行。
    @Test func autorepeatWithoutVerdictFallsBackToWindow() {
        let a = makeAttribution()
        a.recordHIDReport(usage: 0x2C, isDown: true, side: .builtIn, now: 1_000)
        a.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_100)
        a.reset()

        // reset 后两侧时间戳归零(远古),两侧都各有键按着:
        // 旧实现按按下集合并列先查外接,会放行;新实现判内置拦截。
        #expect(a.decide(kind: .keyDown, keyCode: 49, isAutorepeat: true, now: 9_999_999) == .builtIn)
    }

    /// 时间窗归因:更近的一侧胜出;同窗打平判外接(存疑时放行代价更小)。
    @Test func timeWindowPrefersCloserSideAndTiesToExternal() {
        let a = makeAttribution()
        // 仅内置活动:拦截。
        a.recordHIDReport(usage: 0x04, isDown: true, side: .builtIn, now: 1_000)
        #expect(a.decide(kind: .keyDown, keyCode: 4, now: 1_050) == .builtIn)

        // 100ms 内两侧都有活动,外接更近:放行。
        a.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_090)
        #expect(a.decide(kind: .keyDown, keyCode: 11, now: 1_095) == .external)

        // 全新归因器,同刻活动打平:判外接。
        let tied = makeAttribution()
        tied.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_000)
        tied.recordHIDReport(usage: 0x04, isDown: true, side: .builtIn, now: 1_000)
        #expect(tied.decide(kind: .keyDown, keyCode: 4, now: 1_050) == .external)
    }

    /// 无任何证据(如锁定瞬间 tap 先于 HID 收到事件)默认判内置拦截:
    /// 放行即锁定失效,误拦在下一次按键自愈。
    @Test func noEvidenceDefaultsToBuiltIn() {
        let a = makeAttribution()
        #expect(a.decide(kind: .keyDown, keyCode: 4, now: 1_000) == .builtIn)
        #expect(a.decide(kind: .flagsChanged, keyCode: 0, now: 1_000) == .builtIn)
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 1_000) == .builtIn)
    }

    /// 媒体键长按由系统连发,流内沿用首次结论:内置媒体键首判拦截后,即使
    /// 外接侧在连发期间有打字活动,后续连发也不得被逐个翻转成长按穿透。
    @Test func systemDefinedStreamKeepsVerdictAgainstForeignActivity() {
        let a = makeAttribution()
        a.recordHIDReport(usage: 0x2C, isDown: true, side: .builtIn, now: 1_000)
        // 首个媒体键事件:内置活动在窗,判内置拦截。
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 1_100) == .builtIn)

        // 连发期间外接打字,HID 活动更近;流内仍必须沿用拦截结论。
        a.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_300)
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 1_350) == .builtIn)
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 1_550) == .builtIn)

        // 超过流间隔视为新按压,重新走证据链:外接近窗活动 → 放行。
        a.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 2_100)
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 2_200) == .external)
    }

    /// 外接媒体键连发同样受益于流惯性:首判放行后,内置侧活动不得逐个吞掉连发。
    /// 且连发滑动窗口随事件刷新,长按超过 500ms(如长按 1~2 秒调音量)仍持续放行。
    @Test func externalSystemDefinedStreamSurvivesBuiltInActivity() {
        let a = makeAttribution()
        a.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_000)
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 1_050) == .external)

        a.recordHIDReport(usage: 0x2C, isDown: true, side: .builtIn, now: 1_200)
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 1_250) == .external)

        // 连发持续进行(每 150ms 一发):累计时长超过初始 500ms(达到 1_700, 距首发 650ms),
        // 只要各发间隔在 500ms 内,滑动窗口持续续期,不被误判为内置而截断。
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 1_400) == .external)
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 1_550) == .external)
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 1_700) == .external)

        // 连发停止且静默超过 500ms 后,视为新按压;此时内置活动更近 → 判内置拦截。
        a.recordHIDReport(usage: 0x2C, isDown: true, side: .builtIn, now: 2_300)
        #expect(a.decide(kind: .systemDefined, keyCode: 0, now: 2_350) == .builtIn)
    }

    /// 按下态兜底内置优先:窗口皆陈旧且两侧各有键按着时,新按下判内置拦截
    /// (「外接压在内置上」场景外接按下态几乎恒真,外接优先会整体放行);
    /// 外接独占按下仍判外接,不吞外接长按。
    @Test func downSetFallbackPrefersBuiltInWhenBothSidesHeld() {
        let a = makeAttribution()
        a.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_000)
        a.recordHIDReport(usage: 0x2C, isDown: true, side: .builtIn, now: 1_100)
        // 两侧窗口皆陈旧(>100ms),两侧各有键按着:判内置拦截。
        #expect(a.decide(kind: .keyDown, keyCode: 60, now: 5_000) == .builtIn)

        let b = makeAttribution()
        b.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_000)
        #expect(b.decide(kind: .keyDown, keyCode: 60, now: 5_000) == .external)
    }

    /// 抬起无记账时按常规证据归因(外接近窗即放行),并销账不留残留。
    @Test func keyUpWithoutVerdictUsesEvidenceAndClears() {
        let a = makeAttribution()
        a.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_000)
        // 该键记账已被 reset 清空,但外接窗内活动仍在 → 抬起放行。
        a.reset()
        a.recordHIDReport(usage: 0x2C, isDown: true, side: .external, now: 5_000)
        #expect(a.decide(kind: .keyUp, keyCode: 4, now: 5_050) == .external)
    }

    /// reset 清空全部证据与记账:跨轮的按下态与陈旧结论不可作为下一轮证据。
    @Test func resetClearsVerdictsAndDownSets() {
        let a = makeAttribution()
        a.recordHIDReport(usage: 0x04, isDown: true, side: .external, now: 1_000)
        a.decide(kind: .keyDown, keyCode: 4, now: 1_050)
        a.reset()
        // 记账没了:同样的事件重新走证据链,当前无任何证据 → 内置。
        #expect(a.decide(kind: .keyDown, keyCode: 4, isAutorepeat: true, now: 1_100) == .builtIn)
        // 按下集合也没了:新按下走时间窗,同样判内置。
        #expect(a.decide(kind: .keyDown, keyCode: 11, now: 1_150) == .builtIn)
    }

    // MARK: - HID 监控与健壮性状态

    @Test func initialHidMonitoringHealthyIsTrue() {
        let controller = KeyboardLockController()
        #expect(controller.hidMonitoringHealthy == true)
        #expect(controller.connectedExternalKeyboards.isEmpty)
    }

    @Test func refreshHIDMonitoringIsSafeWhenInactive() {
        let controller = KeyboardLockController()
        // 未启动拦截时不持有 tap 与 activeScope，refresh 必须安全短路
        controller.refreshHIDMonitoring()
        #expect(controller.hidMonitoringHealthy == true)
    }

    @Test func scanKeyboardTopologyProducesConsistentResults() {
        let topology = KeyboardLockController.scanKeyboardTopology()
        #expect(topology.externalNames.count >= 0)
        // scanExternalKeyboards 与 scanKeyboardTopology().externalNames 必须等价
        let external = KeyboardLockController.scanExternalKeyboards()
        #expect(topology.externalNames == external)
    }
}
